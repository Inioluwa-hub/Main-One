var sum = function(a,b){
    return a+b
}

for(var i = 1; i <=4; i++){
    
}